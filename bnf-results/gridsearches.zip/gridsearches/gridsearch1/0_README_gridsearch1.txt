-- THE KEY TO UNDERSTANDING GRIDSEARCH1 --

- idea:
Question: how does the length of trajectories influence the accuracy of bnf?
Investigated network: zeroth from big pkl (5-nodes)
step: 1
mode: sync/async
trajectories lenght: 10, 20, 50
attractor_fraction: relatively big/relatively small for specified parameters above
scoring: MDL/BDE 

OUTPUT: 24 bnf files, 4 parameters changed.

- investigated bn:
nodes_readable: ((2, 2), (4, 3), (3, 4))
list_of_functions: ['0', '1', '~x2', '~x4', 'x3']

- what does the filename say about the file:
a/s - mode async/sync
10/20/50 - length of trajectories list
0/1 - relatively small/big value of attractor_fraction

- additional info:
value of attractor_fraction for each set of trajectories can be checked in gridsearch.xlsx