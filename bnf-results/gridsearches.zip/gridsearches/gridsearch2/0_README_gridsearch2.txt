-- THE KEY TO UNDERSTANDING GRIDSEARCH2 --

- idea:
Question: how does the number of nodes influence the accuracy of bnf?
Investigated networks: zeroth from big pkl (5-nodes), first from big pkl (10-nodes), second from big pkl (16-nodes)
no of nodes: 5, 10, 16
step: 1,2,3
mode: sync/async
trajectories lenght: 10
attractor fraction: relatively big for specified parameters
scoring: MDL/BDE 

OUTPUT: 36 bnf files, 4 parameters changed.

- investigated bns:
5-node bn:
nodes_readable: ((2, 2), (4, 3), (3, 4))
list_of_functions: ['0', '1', '~x2', '~x4', 'x3']

10-node bn:
nodes_readable: ((1, 1), (2, 1), (6, 1), (1, 2), (3, 2), (4, 2), (2, 3), (5, 3), (5, 4), (6, 4), (8, 4), (0, 5), (7, 5), (8, 5), (1, 6), (8, 6), (9, 6), (1, 9), (4, 9), (6, 9))
list_of_functions: ['1', '((x2 | ~x1) | x6)', '((~x4 & ~x3) & ~x1)', '(x5 & ~x2)', '((x6 | x5) | ~x8)', '((x0 & x8) & ~x7)', '((x9 & x8) & x1)', '1', '1', '((x1 | x4) & x6)']

16-node bn:
nodes_readable: ((8, 0), (13, 0), (2, 2), (2, 3), (5, 3), (11, 3), (1, 4), (4, 5), (11, 5), (14, 5), (15, 6), (1, 8), (2, 9), (6, 9), (14, 9), (4, 10), (0, 11), (4, 11), (12, 12), (9, 13), (4, 15), (5, 15), (14, 15))

list_of_functions: ['(x8 & ~x13)', '1', 'x2', '((x2 | x11) | ~x5)', 'x1', '((x14 & x11) & x4)', '~x15', '1', 'x1', '((~x6 & ~x14) | x2)', '~x4', '(x0 & x4)', 'x12', 'x9', '0', '((x4 | x5) | x14)']


- what does the filename say about the file:
5/10/16 - number of nodes in the net
a/s - mode async/sync
1/2/3 - step size
