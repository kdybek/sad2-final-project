-- THE KEY TO UNDERSTANDING GRIDSEARCH3 --

- idea:
Question: how does the length of trajectories influence the accuracy of bnf?
Investigated network: first from big pkl (10-nodes)
step: 1
mode: sync/async
trajectories lenght: 10, 20, 50
attractor_fraction: relatively big/relatively small for specified parameters above
scoring: MDL/BDE 

OUTPUT: 24 bnf files, 4 parameters changed.

- investigated bn:
nodes_readable: ((1, 1), (2, 1), (6, 1), (1, 2), (3, 2), (4, 2), (2, 3), (5, 3), (5, 4), (6, 4), (8, 4), (0, 5), (7, 5), (8, 5), (1, 6), (8, 6), (9, 6), (1, 9), (4, 9), (6, 9))
list_of_functions: ['1', '((x2 | ~x1) | x6)', '((~x4 & ~x3) & ~x1)', '(x5 & ~x2)', '((x6 | x5) | ~x8)', '((x0 & x8) & ~x7)', '((x9 & x8) & x1)', '1', '1', '((x1 | x4) & x6)']

- what does the filename say about the file:
a/s - mode async/sync
10/20/50 - length of trajectories list
0/1 - relatively small/big value of attractor_fraction

- additional info:
value of attractor_fraction for each set of trajectories can NOT be checked in gridsearch.xlsx